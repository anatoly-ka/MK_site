let homeButton = document.getElementById("home") as HTMLButtonElement;
homeButton.addEventListener("click", function() {
    window.location.href = "index.html";
});
let bookButton = document.getElementById("book") as HTMLButtonElement;
bookButton.addEventListener("click", function() {
    window.location.href = "books.html";
});
let otherButton = document.getElementById("other") as HTMLButtonElement;
otherButton.addEventListener("click", function() {
    window.location.href = "other.html";
}); 
let yutButton = document.getElementById("yut") as HTMLButtonElement;
yutButton.addEventListener("click", function() {
    window.location.href = "video.html";
});
interface Poem {
    title: string;
    text: string;
}

const poems: Poem[] = [
    {
        title: "Неиспитая любовь...",
        text: `Неиспитая любовь
И непонятость желаний,
И надежда ожиданий,
И невысказанность слов.

Ненаписанных стихов
Неиспытанная радость,
Неизведанная сладость
Горьковато-терпких снов...`
    },
    {
        title: "Храня торжственную грусть...",
        text: `Храня торжственную грусть,
Она вошла под своды Храма,
Вуаль скрывала хрупкость плеч,
Но брови сдвинуты упрямо.

Она молилась за того,
Кто был дороже всех на свете,
И знала, что пред алтарём
Наутро брак с ним не осветит.

Готова жертву принести,
Согласна стать чужой невестой,
Она ему не навредит
Ни словом, ни случайным жестом.

И неизменно холодна
Пройдёт под руку вместе с мужем.
Вот в церкви почему она,
И почему ей Б-г так нужен!`
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
    {
        title: "...",
        text: ``
    },
];


const poemList = document.getElementById("poemList") as HTMLUListElement;
const poemDialog = document.getElementById("poemDialog") as HTMLDialogElement;
const poemTitle = document.getElementById("poemTitle") as HTMLElement;
const poemText = document.getElementById("poemText") as HTMLElement;
const closeDialog = document.getElementById("closeDialog") as HTMLButtonElement;


poems.forEach((poem, index) => {
    const li = document.createElement("li");
    li.textContent = poem.title;
    li.onclick = () => openPoem(index);
    poemList.appendChild(li);
});


function openPoem(index: number) {
    poemTitle.textContent = poems[index].title;
    poemText.textContent = poems[index].text;
    poemDialog.showModal();
}

closeDialog.onclick = () => {
    poemDialog.close();
};
