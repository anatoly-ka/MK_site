

            let homeButton = document.getElementById("home") as HTMLButtonElement;
            homeButton.addEventListener("click", function() {
                window.location.href = "index.html";
            });
            let bookButton = document.getElementById("book") as HTMLButtonElement;
            bookButton.addEventListener("click", function() {
                window.location.href = "books.html";
            });
            let otherButton = document.getElementById("other") as HTMLButtonElement;
            otherButton.addEventListener("click", function() {
                window.location.href = "other.html";
            }); 
            let yutButton = document.getElementById("yut") as HTMLButtonElement;
            yutButton.addEventListener("click", function() {
                window.location.href = "video.html";
            });
  interface Poem {
    title: string;
    text: string;
}

const poems: Poem[] = [
    {
        title: "The First Poem",
        text: `Roses are redבחךיץך קאךןלין חיכחסעףדעכווווווזי כןעישלדףךוכסעךשלתדעכפךןועפןרוךזסעכלבהךןלחגעשכזסבןל
        הלחנץ ליכהלחנץלחזתכהבלץתנז
        כילחיבחלילחנ
        לחכיהנהוכלחלח
        כחבנחיכעה כסחבעלגב
        יןחנחיעםןנטונחים
        חןבעיחהןנביחכהגעועון
        'וטנקרלחדטי ךל
        ןכיח
        יחכנחיעצ
        יטוחחיעןחזה
        בחןגנןועכ
        חחעועןחינ
        חויהיחעיך 
        עטע חןועטכ[וט
        חו לןא
        בוק רלגחב
        חעון ול ע
     
     ןךן
     
     בכגרא
     כעכ
     
     כעעג
     
     כ
     כ
     
     
     כ
     כ
     כ
     כ
     כ
     כ
     
     
     ככ
     כ
     
     כ
     ככ
     כ
     כ
     כ
     
     כ
     י
     ע
     כע,
     כ
     כ
     כ
     כ
     
     כ
     
     כ
     
     כ
     כ
     כ
     ,
     ע
     ,, 
     ,ע,
     ו ןועדטכם],`
    },
    { 
        title: "The Second Poem",
        text: `The sun sets low, painting skies with gold,
Whispers of night in stories untold.
Stars emerge, a glittering sea,
Dreams take flight, wild and free.  
    }`,
  
];


const poemList = document.getElementById("poemList") as HTMLUListElement;
const poemDialog = document.getElementById("poemDialog") as HTMLDialogElement;
const poemTitle = document.getElementById("poemTitle") as HTMLElement;
const poemText = document.getElementById("poemText") as HTMLElement;
const closeDialog = document.getElementById("closeDialog") as HTMLButtonElement;


poems.forEach((poem, index) => {
    const li = document.createElement("li");
    li.textContent = poem.title;
    li.onclick = () => openPoem(index);
    poemList.appendChild(li);
});


function openPoem(index: number) {
    poemTitle.textContent = poems[index].title;
    poemText.textContent = poems[index].text;
    poemDialog.showModal();
}

closeDialog.onclick = () => {
    poemDialog.close();
};
